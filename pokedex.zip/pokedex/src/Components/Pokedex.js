import React,{Component} from 'react';
import './../styles/Pokedex.css';
import Pokecard from './Pokecard';

class Pokedex extends Component {
    render() { 
        return ( 
            <div className="Pokedex">
                <h1 className={`Pokedex-title ${this.props.colorClass}`}>{this.props.message}</h1>
                <h4 className="Pokedex-title"> Total experience: {this.props.exp} </h4>
               <div className="Pokedex-cards"> {this.props.pokemon.map((poke)=>(
                   <Pokecard key={poke.id} id={poke.id} name={poke.name} type={poke.type} exp={poke.base_experience} />
               ))}
                </div>
            </div>
         );
    }
}
 
export default Pokedex;