import React, { Component } from 'react';

import pokemonData from '../helpers/PokemonData';
import Pokedex from './Pokedex';

import '../styles/Pokegame.css';

class Pokegame extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        let hand1=[];
        let hand2=[...pokemonData];
        let hand1_total_exp=0;
        let hand2_total_exp=0;
        let hand1_message='';
        let hand2_message='';
        let hand1Class='';
        let hand2Class='';

        while(hand1.length < hand2.length ){
            let randomidx =Math.floor(Math.random() * hand2.length);
            let randPokemon=hand2.splice(randomidx,1)[0];
            hand1.push(randPokemon);
        }
        for(var i=0;i<hand1.length;i++){
            hand1_total_exp=hand1_total_exp+hand1[i]['base_experience'];
            hand2_total_exp=hand2_total_exp+hand2[i]['base_experience'];
        }
       
        if(hand1_total_exp > hand2_total_exp){
            hand1_message="You are winner";
            hand2_message="You are loser";
            hand1Class="Pokedex-winner";
            hand2Class="Pokedex-loser";
        }
        else{
            hand1_message="You are loser";
            hand2_message="You are winner";
            hand1Class="Pokedex-loser";
            hand2Class="Pokedex-winner";

        }



      

        return ( 
            <div className="Pokegame">
                <h1 className="Pokegame-heading">Pokegame!</h1>
                <Pokedex pokemon={hand1} message={hand1_message} colorClass={hand1Class} exp={hand1_total_exp} />
                <Pokedex pokemon={hand2} message={hand2_message} colorClass={hand2Class} exp={hand2_total_exp} />  
            </div>
         );
    }
}
 
export default Pokegame;
