
import React,{Component} from 'react';
import './../styles/Pokecard.css';

import Paddingfunction from '../helpers/padLeadingZero';

const IMG_API='https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/';

const {REACT_APP_IMG_API}=process.env;
const REACT_APP_IMG_API_FANCY='https://assets.pokemon.com/assets/cms2/img/pokedex/detail/';
class Pokecard extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        const PaddingIds=Paddingfunction(this.props.id,3);

        let imgSrc=`${REACT_APP_IMG_API_FANCY}${PaddingIds}.png`;
        return ( 
           <div className="Pokecard">
               <h1  className="Pokecard-name">{this.props.name}</h1>
               <div className="Pokecard-img"><img  src={imgSrc} alt={this.props.name} /> </div>
               <p   className="Pokecard-type"> Type: {this.props.type}</p>
               <p   className="Pokecard-exp">Experience: {this.props.exp}</p>
           </div> 
         );
    }
}
 
export default Pokecard;