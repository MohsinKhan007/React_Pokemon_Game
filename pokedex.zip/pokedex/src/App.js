import logo from './logo.svg';
import './App.css';

import Pokedex from './Components/Pokedex';
import Pokegame from './Components/Pokegame';


function App() {
  // console.log(JSON.stringify(PokemonArray));
  return (
    <div className="App">    
         {/* <Pokedex/> */}
         <Pokegame/>
    </div>
  );
}

export default App;
